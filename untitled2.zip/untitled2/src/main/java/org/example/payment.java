package org.example;

public class payment {
    private String payMethod;


    /**
     * @param payMethod
     */
    public void setPayMethod(String payMethod)
    {
        this.payMethod = payMethod;
    }

    /**
     * @return String
     */
    public String getPayMethod()
    {
        return payMethod;
    }

}
